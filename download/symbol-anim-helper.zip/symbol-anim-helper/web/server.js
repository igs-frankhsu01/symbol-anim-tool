// 簡易圖騰動畫產生器的本機小幫手：讀取流程的設定與輸出給網頁看，也可以從網頁執行各步驟（呼叫本機 Photoshop、Spine）。
// 只聽 127.0.0.1；讀檔範圍限定在工具資料夾與設定檔的專案 root 底下。
// 網頁可以是它自己提供的（localhost:8810）、本機煉丹爐（localhost:8800/symbol-anim/），或 helper.json 允許的線上網址（GitHub Pages）。
// 用法：node web/server.js [port]（預設 8810）
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const TOOL = path.resolve(__dirname, '..');
const VERSION = '0.2.0';
const PY = path.join(TOOL, '.venv', 'Scripts', 'python.exe');
const PORT = +process.argv[2] || 8810;
// 本機設定：helper.json（可不建，全部用預設）。範例見 helper.example.json
// 部署位置（線上介面、線上煉丹爐）：deploy.json，換主機只改那裡
// 本機煉丹爐（_Workbench/projects）：在這些資料夾底下找，第一個有的就是
const findWorkbench = dirs => dirs.map(d => path.join(d, '_Workbench')).find(w => fs.existsSync(path.join(w, 'projects')));
const subdirs = d => { try { return fs.readdirSync(d, { withFileTypes: true }).filter(e => e.isDirectory() && !e.name.startsWith('$')).map(e => path.join(d, e.name)); } catch { return []; } };
const ancestors = p => { const a = []; for (let d = path.dirname(p); d !== path.dirname(d); d = path.dirname(d)) a.push(d); return a; };
const DEPLOY = (() => { try { return JSON.parse(fs.readFileSync(path.join(TOOL, 'deploy.json'), 'utf8')); } catch { return {}; } })();
DEPLOY.uiUrl ||= 'https://igs-frankhsu01.github.io/symbol-anim-tool/';
const SETTINGS = (() => {
  let s = {};
  try { s = JSON.parse(fs.readFileSync(path.join(TOOL, 'helper.json'), 'utf8')); } catch {}
  const workRoot = path.resolve(s.workRoot || path.resolve(TOOL, '../../..'));
  return {
    workRoot,                                                    // 找 PSD、推專案資料夾的根目錄
    workbench: path.resolve(s.workbench || findWorkbench([path.resolve(TOOL, '../../..'), workRoot, ...subdirs(workRoot)]) || path.join(workRoot, '_Workbench')),
    spineExe: s.spineExe || 'C:/Program Files/Spine/Spine.com',
    allowOrigins: s.allowOrigins || [new URL(DEPLOY.uiUrl).origin],
  };
})();
// 播放器：有煉丹爐就用它的，沒有就用小幫手自帶的（下載包裡的 web/vendor）
const VENDOR = fs.existsSync(path.join(SETTINGS.workbench, 'vendor', 'pixi-spine.js')) ? path.join(SETTINGS.workbench, 'vendor') : path.join(__dirname, 'vendor');
fs.mkdirSync(path.join(TOOL, 'configs'), { recursive: true });
const LOCAL_ORIGIN = /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/;
const originOk = o => !o || LOCAL_ORIGIN.test(o) || SETTINGS.allowOrigins.includes(o);
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.mp4': 'video/mp4', '.atlas': 'text/plain', '.skel': 'application/octet-stream' };

const readJSON = p => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } };
const configPath = name => path.join(TOOL, 'configs', path.basename(name) + '.json');
function resolveCfg(name, spineDirOverride) {
  const cfg = readJSON(configPath(name));
  if (!cfg) throw new Error('找不到設定檔 ' + name);
  const abs = p => path.isAbsolute(p) ? p : path.join(cfg.root, p);
  const spineDir = spineDirOverride || abs(cfg.spine.dir);
  if (spineDirOverride) trialRoots.add(path.resolve(spineDirOverride));
  const spineName = cfg.spine.name || path.basename(spineDir);
  return { cfg, abs, spineDir, spineName, work: path.join(TOOL, 'work', name) };
}
const trialRoots = new Set();  // 網頁指定的試跑資料夾，也允許讀取
// 設定檔的專案 root，以及存放位置不在 root 底下的 Spine 資料夾
const allowedRoots = () => [TOOL, VENDOR, ...trialRoots, ...fs.readdirSync(path.join(TOOL, 'configs')).map(f => readJSON(path.join(TOOL, 'configs', f))).filter(c => c?.root)
  .flatMap(c => [c.root, ...(c.spine?.dir && path.isAbsolute(c.spine.dir) ? [c.spine.dir] : [])]).map(r => path.resolve(r))];
const inside = (p, root) => { const r = path.relative(root, p); return !r.startsWith('..') && !path.isAbsolute(r); };

function sendFile(res, p) {
  p = path.resolve(p);
  if (!allowedRoots().some(r => inside(p, r))) { res.writeHead(403); return res.end('不在允許範圍'); }
  fs.stat(p, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('找不到'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(p).toLowerCase()] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-store' });
    fs.createReadStream(p).pipe(res);
  });
}
const json = (res, data, code = 200) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(data)); };
const list = (dir, re) => { try { return fs.readdirSync(dir).filter(f => re.test(f)).map(f => path.join(dir, f)); } catch { return []; } };

// 展示台登記狀態：每個圖騰在 assets.json 裡有沒有指到這次的 skel
function showcaseState(c) {
  const sc = c.cfg.showcase;
  if (!sc) return null;
  const assets = readJSON(sc.assets);
  if (!assets) return { assets: sc.assets, missing: true, rows: [] };
  const exportRel = path.relative(c.cfg.root, path.join(c.spineDir, 'Export')).replace(/\\/g, '/');
  const rows = c.cfg.symbols.map(s => {
    const code = s.showcaseCode || s.code, e = assets.symbols?.[code];
    const skel = `${exportRel}/${c.cfg.naming.skeleton.replace('{project}', c.cfg.project).replace('{code}', s.code)}.skel`;
    return { code, skel: e?.spine?.skel || null, win: e?.anims?.win || null, ok: e?.spine?.skel === skel };
  });
  return { assets: sc.assets, spineSize: assets.spineSize || null, rows };
}

// 放入的設定檔：檢查必要欄位後存進 configs/（同名但內容不同就加序號，不覆蓋）
const REQUIRED = ['project', 'root', 'psd', 'symbols', 'naming', 'output', 'animation', 'spine'];
function saveConfig(filename, content) {
  let cfg;
  try { cfg = JSON.parse(content); } catch (e) { throw new Error('不是有效的 JSON：' + e.message); }
  const lack = REQUIRED.filter(k => !(k in cfg));
  if (lack.length) throw new Error('設定檔缺少欄位：' + lack.join('、'));
  if (!Array.isArray(cfg.symbols) || !cfg.symbols.length) throw new Error('symbols 至少要有一個圖騰');
  if (!fs.existsSync(path.isAbsolute(cfg.psd) ? cfg.psd : path.join(cfg.root, cfg.psd))) throw new Error('找不到 PSD：' + cfg.psd);
  const base = path.basename(filename, '.json').replace(/[^\w\-一-鿿]/g, '_') || 'config';
  let name = base, n = 1;
  while (fs.existsSync(configPath(name)) && fs.readFileSync(configPath(name), 'utf8') !== content) name = `${base}_${++n}`;
  fs.writeFileSync(configPath(name), content, 'utf8');
  return name;
}

// ---------- 直接丟 PSD ----------
const HOME = SETTINGS.workRoot;
let WORKBENCH = SETTINGS.workbench;
const SKIP_DIRS = new Set(['node_modules', '.git', '.venv', 'work', 'backup', 'Export', 'Images', 'Previews', 'dist', 'vendor']);

// 瀏覽器拿不到檔案路徑：用檔名＋大小在虎機資料夾底下找原檔
function locatePsd(name, size) {
  const hits = [], stack = [HOME];
  let dirs = 0;
  while (stack.length && dirs < 40000) {
    const d = stack.pop(); dirs++;
    let ents; try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch { continue; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name) && !e.name.startsWith('.')) stack.push(p); }
      else if (e.name === name) { try { if (fs.statSync(p).size === size) hits.push(p); } catch {} }
    }
  }
  return hits;
}

// 由 PSD 位置推預設值：
// 專案 root＝本機煉丹爐展示台登記過的專案資料夾（PSD 往上找）；沒有的話是 PSD 所在資料夾的上一層（例如 專案/01_設定/x.psd → 專案）
function psdDefaults(psdPath) {
  const ups = ancestors(psdPath);
  if (!fs.existsSync(path.join(WORKBENCH, 'projects'))) WORKBENCH = findWorkbench(ups) || WORKBENCH;
  const shows = (() => { try { return fs.readdirSync(path.join(WORKBENCH, 'projects')); } catch { return []; } })()
    .map(id => ({ file: path.join(WORKBENCH, 'projects', id, 'assets.json') })).map(x => ({ ...x, root: readJSON(x.file)?.root })).filter(x => x.root);
  let root = null, showcase = null;
  for (const d of ups) { const hit = shows.find(x => x.root === path.basename(d)); if (hit) { root = d; showcase = hit.file; break; } }
  if (!root) root = ups[1] || ups[0] || path.dirname(psdPath);
  const project = path.basename(root).replace(/^\d+_?/, '').replace(/[^A-Za-z0-9]/g, '');
  const existing = fs.readdirSync(path.join(TOOL, 'configs')).filter(f => f.endsWith('.json')).map(f => ({ name: path.basename(f, '.json'), cfg: readJSON(path.join(TOOL, 'configs', f)) }))
    .filter(x => x.cfg && path.resolve(path.isAbsolute(x.cfg.psd) ? x.cfg.psd : path.join(x.cfg.root, x.cfg.psd)) === path.resolve(psdPath)).map(x => x.name);
  return { root: root.replace(/\\/g, '/'), project, psdRel: path.relative(root, psdPath).replace(/\\/g, '/'), showcase: showcase && showcase.replace(/\\/g, '/'), workbench: shows.length > 0, existing };
}

function analyzePsd(psdPath) {
  return new Promise((ok, fail) => {
    const out = path.join(TOOL, 'work', '_analyze', Buffer.from(psdPath).toString('base64url').slice(-40));
    const p = spawn(PY, ['-I', path.join(TOOL, 'utils', 'analyze_psd.py'), psdPath, out], { env: { ...process.env, PYTHONIOENCODING: 'utf-8' } });
    let so = '', se = '';
    p.stdout.on('data', d => so += d); p.stderr.on('data', d => se += d);
    p.on('close', code => { try { if (code) throw new Error(se.split('\n').filter(l => !/deprecated/.test(l)).join('\n').slice(-600)); ok({ psd: psdPath.replace(/\\/g, '/'), ...JSON.parse(so), defaults: psdDefaults(psdPath) }); } catch (e) { fail(e); } });
  });
}

// ---------- 展示台（煉丹爐本機伺服器 _Workbench/serve.js） ----------
const SHOWCASE_PORT = 8800;
const pingShowcase = () => new Promise(ok => {
  const r = http.get({ host: '127.0.0.1', port: SHOWCASE_PORT, path: '/showcase/index.html', timeout: 800 }, res => { res.resume(); ok(res.statusCode === 200); });
  r.on('error', () => ok(false)); r.on('timeout', () => { r.destroy(); ok(false); });
});
async function startShowcase() {
  if (await pingShowcase()) return true;
  spawn(process.execPath, [path.join(WORKBENCH, 'serve.js'), String(SHOWCASE_PORT)], { cwd: WORKBENCH, detached: true, stdio: 'ignore', windowsHide: true }).unref();
  for (let i = 0; i < 20; i++) { await new Promise(r => setTimeout(r, 250)); if (await pingShowcase()) return true; }
  return false;
}

// 選資料夾：網頁拿不到本機路徑，由小幫手開 Windows 的選資料夾視窗
// 小幫手在背景執行，視窗會開在瀏覽器後面：用看不見、但已顯示的最上層視窗當擁有者，對話框才會跟著蓋在最上面
function pickFolder(start) {
  const ps = `Add-Type -AssemblyName System.Windows.Forms
$o = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false; FormBorderStyle = 'None'; Opacity = 0; StartPosition = 'Manual'; Size = '1,1' }
$a = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$o.Location = New-Object System.Drawing.Point(($a.Width / 2), ($a.Height / 2))
$o.Show(); $o.Activate()
$d = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{ Description = '選擇存放 Spine 專案的資料夾'; ShowNewFolderButton = $true }
$s = $env:PICK_START; while ($s -and -not (Test-Path -LiteralPath $s)) { $s = Split-Path $s }
if ($s) { $d.SelectedPath = (Resolve-Path -LiteralPath $s).Path }
if ($d.ShowDialog($o) -eq 'OK') { [Console]::OutputEncoding = [Text.Encoding]::UTF8; [Console]::Write($d.SelectedPath) }`;
  return new Promise(ok => {
    const p = spawn('powershell', ['-NoProfile', '-STA', '-Command', ps], { env: { ...process.env, PICK_START: start || '' }, windowsHide: true });
    let so = ''; p.stdout.on('data', d => so += d.toString('utf8'));
    p.on('close', () => ok(so.trim() ? so.trim().replace(/\\/g, '/') : null)); p.on('error', () => ok(null));
  });
}

// 確認畫面的表單 → 設定檔（存進 configs/，之後同一份 PSD 可直接重跑）
function createConfig(f) {
  if (!/^[A-Za-z0-9]+$/.test(f.project || '')) throw new Error('專案名稱只能用英數字（命名規範 R-2.1）');
  if (!/^[A-Za-z0-9_]+$/.test(f.group || '')) throw new Error('組名只能用英數字與底線');
  const syms = (f.symbols || []).filter(s => s.code);
  if (!syms.length) throw new Error('至少勾選一個圖騰');
  const bad = syms.filter(s => !/^[A-Za-z0-9_]+$/.test(s.code));
  if (bad.length) throw new Error('圖騰代號只能用英數字與底線：' + bad.map(s => s.layer).join('、'));
  const dup = syms.map(s => s.code).filter((c, i, a) => a.indexOf(c) !== i);
  if (dup.length) throw new Error('圖騰代號重複：' + [...new Set(dup)].join('、'));
  const d = psdDefaults(f.psd);
  const spineName = `${f.project}_Symbol_${f.group}`;
  // 存放位置：網頁可改（預設 專案/03_Spine）；在專案 root 底下就存相對路徑
  if (f.outParent && !path.isAbsolute(f.outParent)) throw new Error('存放位置要是完整路徑（例如 D:/專案/03_Spine）');
  const outParent = path.resolve(f.outParent || path.join(d.root, '03_Spine'));
  const spineAbs = path.join(outParent, spineName);
  const spineRel = inside(spineAbs, d.root) ? path.relative(d.root, spineAbs).replace(/\\/g, '/') : spineAbs.replace(/\\/g, '/');
  if (f.showcase && d.showcase && path.isAbsolute(spineRel)) throw new Error(`要登記展示台的話，存放位置要在專案資料夾 ${d.root} 底下（展示台只讀得到那裡）`);
  const cfg = {
    _說明: `${f.project} ${f.group}（${syms.map(s => s.code).join(' ')}），由操作網頁從 PSD 產生（${new Date().toISOString().slice(0, 10)}）。輸出 ${f.scale}${f.size ? ` → ${f.size.join('×')}` : ''}。`,
    project: f.project, root: d.root, psd: d.psdRel,
    symbols: syms.map(s => ({ code: s.code, layer: s.layer, ...(s.occurrence > 1 ? { occurrence: s.occurrence } : {}) })),
    naming: { skeleton: '{project}_Symbol_{code}', image: 'Symbol_{code}', bone: 'Main' },
    textureScale: 1.0,
    output: { scale: +f.scale, ...(f.size ? { size: f.size } : {}) },
    animation: { name: f.animName || 'Bingo', template: f.template || 'bingo_pulse', fps: 30 },
    spine: { dir: spineRel, exe: SETTINGS.spineExe, version: '3.8.99' },
    export: { packTarget: f.packTarget || 'all' },
    verify: { tolerance: 2 },
    ...(f.showcase && d.showcase ? { showcase: { assets: d.showcase, spineSize: f.size || null } } : {}),
  };
  const name = `${f.project}_${f.group}`.toLowerCase();
  // 同名設定檔已存在：保留手動加過的版面對照、預覽設定
  const old = readJSON(configPath(name));
  if (old?.verify?.layout) cfg.verify.layout = old.verify.layout;
  if (old?.preview) cfg.preview = old.preview;
  fs.writeFileSync(configPath(name), JSON.stringify(cfg, null, 2) + '\n', 'utf8');
  return name;
}

// 目前狀態：設定、各步驟輸出與驗證報告
function state(name, spineDir) {
  const c = resolveCfg(name, spineDir);
  const exportDir = path.join(c.spineDir, 'Export');
  const atlasFile = list(exportDir, /\.atlas$/i);
  return {
    name, config: c.cfg, spineDir: c.spineDir, spineFile: path.join(c.spineDir, c.spineName + '.spine'), work: c.work,
    psd: c.abs(c.cfg.psd),
    template: readJSON(path.join(TOOL, 'templates', 'anim', c.cfg.animation.template + '.json')),
    photoshopLog: readJSON(path.join(c.work, 'photoshop', 'photoshop_log.json')),
    textures: readJSON(path.join(c.work, 'textures.json')),
    size: readJSON(path.join(c.work, 'size.json')),
    // 確認尺寸時 Spine 算出的第 0 格（輸出前就有，讓舞台先看得到）
    renders: Object.fromEntries(list(path.join(c.work, 'verify', 'render'), /_0+\.png$/i).map(p => [path.basename(p).replace(/-[^-]+_0+\.png$/i, ''), { path: p, mtime: fs.statSync(p).mtimeMs }])),
    report: readJSON(path.join(c.work, 'report.json')),
    showcase: showcaseState(c),
    exportFiles: list(exportDir, /./).map(p => ({ path: p, size: fs.statSync(p).size, mtime: fs.statSync(p).mtimeMs })),
    atlas: atlasFile.map(p => ({ path: p, text: fs.readFileSync(p, 'utf8') })),
    previews: list(path.join(c.spineDir, 'Previews'), /\.(png|jpg|mp4|webp)$/i),
    reference: c.cfg.verify?.layout?.reference ? c.abs(c.cfg.verify.layout.reference) : null,
    spineMtime: fs.existsSync(path.join(c.spineDir, c.spineName + '.spine')) ? fs.statSync(path.join(c.spineDir, c.spineName + '.spine')).mtimeMs : null,
  };
}

// 執行中的工作（一次只跑一個）
let job = { running: false, code: null, log: '', started: null, args: null };
function runJob({ config, steps, spineDir, force }) {
  if (job.running) throw new Error('已有步驟在執行');
  // -u：不緩衝輸出，網頁才拿得到即時紀錄與目前步驟
  const args = ['-u', path.join(TOOL, 'run.py'), configPath(config), '--steps', steps.join(',')];
  if (spineDir) args.push('--spine-dir', spineDir);
  if (force) args.push('--force');
  job = { running: true, code: null, log: '', started: Date.now(), args };
  const p = spawn(PY, args, { cwd: TOOL, env: { ...process.env, PYTHONIOENCODING: 'utf-8' } });
  const add = d => { job.log += d.toString('utf8'); };
  p.stdout.on('data', add); p.stderr.on('data', add);
  p.on('close', code => { job.running = false; job.code = code; });
  p.on('error', e => { job.running = false; job.code = -1; job.log += '\n無法啟動：' + e.message; });
}

// 送進煉丹爐收件批次：Spine 專案的 Export 與 Images（含子資料夾），路徑以專案資料夾名開頭
function bundle(name, spineDir) {
  const c = resolveCfg(name, spineDir), root = path.basename(c.spineDir), files = [];
  const walk = (d, rel) => { if (!fs.existsSync(d)) return; for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, e.name);
    if (e.isDirectory()) walk(p, `${rel}/${e.name}`); else files.push({ path: `${rel}/${e.name}`, abs: p.replace(/\\/g, '/') });
  } };
  for (const sub of ['Export', 'Images']) walk(path.join(c.spineDir, sub), `${root}/${sub}`);
  return { name: root, files };
}

// 環境檢查：線上介面連進來時先看這台電腦能不能跑
const exists = p => { try { return fs.existsSync(p); } catch { return false; } };
const succeeds = (cmd, args) => new Promise(ok => {
  const p = spawn(cmd, args, { windowsHide: true, stdio: 'ignore' });
  p.on('close', code => ok(code === 0)); p.on('error', () => ok(false));
});
const photoshopInstalled = () => succeeds('reg', ['query', 'HKCR\\Photoshop.Application']);
async function helperInfo() {
  return {
    tool: 'symbol-anim', version: VERSION, workRoot: SETTINGS.workRoot.replace(/\\/g, '/'),
    deploy: { uiUrl: DEPLOY.uiUrl, workbenchUrl: DEPLOY.workbenchUrl || null },
    checks: [
      { id: 'photoshop', name: 'Photoshop', ok: await photoshopInstalled(), hint: '需要安裝 Photoshop（拆圖時會自動開啟）' },
      { id: 'spine', name: 'Spine 3.8.99', ok: exists(SETTINGS.spineExe), hint: `找不到 ${SETTINGS.spineExe}，可在 helper.json 的 spineExe 指定` },
      { id: 'python', name: 'Python 環境', ok: exists(PY), hint: '工具資料夾裡還沒建 .venv（見 README）' },
      { id: 'workRoot', name: '工作根目錄', ok: exists(SETTINGS.workRoot), hint: `找不到 ${SETTINGS.workRoot}，可在 helper.json 的 workRoot 指定` },
      { id: 'ffmpeg', name: 'ffmpeg（預覽影片）', ok: await succeeds('where', ['ffmpeg']), optional: true, hint: '沒有也能做動畫，只是不產生預覽影片；install.cmd 可以幫你裝' },
      { id: 'workbench', name: '本機煉丹爐（登記展示台）', ok: exists(path.join(SETTINGS.workbench, 'projects')), optional: true, hint: '沒有也能做動畫；做好的 Spine 資料夾拖進線上煉丹爐的收件區即可' },
    ],
  };
}

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  // 跨網址連線：只接受本機與 helper.json 允許的網址；其他網站來的請求一律拒絕（避免被別的網頁操作）
  const origin = req.headers.origin;
  if (!originOk(origin)) { res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('這個網址不在小幫手的允許清單（helper.json 的 allowOrigins）'); }
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Private-Network': 'true', 'Access-Control-Max-Age': '600' });
    return res.end();
  }
  try {
    if (u.pathname === '/api/helper') { helperInfo().then(r => json(res, r)); return; }
    if (u.pathname === '/api/configs') return json(res, list(path.join(TOOL, 'configs'), /\.json$/i).map(p => ({ name: path.basename(p, '.json'), note: readJSON(p)?._說明 || '' })));
    if (u.pathname === '/api/state') return json(res, state(u.searchParams.get('config'), u.searchParams.get('spineDir') || null));
    if (u.pathname === '/api/job') return json(res, job);
    if (u.pathname === '/api/bundle') return json(res, bundle(u.searchParams.get('config'), u.searchParams.get('spineDir') || null));
    if (u.pathname === '/api/showcase/status') { pingShowcase().then(up => json(res, { up, port: SHOWCASE_PORT })); return; }
    if (u.pathname === '/api/showcase/start' && req.method === 'POST') { startShowcase().then(up => json(res, { up, port: SHOWCASE_PORT })); return; }
    if (u.pathname === '/api/pick-folder' && req.method === 'POST') { pickFolder(u.searchParams.get('start')).then(p => json(res, { path: p })); return; }
    if (u.pathname === '/api/templates') return json(res, list(path.join(TOOL, 'templates', 'anim'), /\.json$/i).map(p => ({ name: path.basename(p, '.json'), description: readJSON(p)?.description || '' })));
    if (u.pathname === '/api/psd/locate') return json(res, { hits: locatePsd(u.searchParams.get('name'), +u.searchParams.get('size')).map(p => p.replace(/\\/g, '/')) });
    if (u.pathname === '/api/psd/analyze') {
      const p = path.resolve(u.searchParams.get('path') || '');
      if (!/\.ps[db]$/i.test(p) || !fs.existsSync(p)) return json(res, { error: '找不到 PSD：' + p }, 400);
      analyzePsd(p).then(r => json(res, r), e => json(res, { error: 'PSD 分析失敗：' + e.message }, 500));
      return;
    }
    if (u.pathname === '/api/config/create' && req.method === 'POST') {
      let body = '';
      req.on('data', d => body += d);
      req.on('end', () => { try { json(res, { name: createConfig(JSON.parse(body)) }); } catch (e) { json(res, { error: e.message }, 400); } });
      return;
    }
    if (u.pathname === '/api/config' && req.method === 'POST') {
      let body = '';
      req.on('data', d => body += d);
      req.on('end', () => { try { const { filename, content } = JSON.parse(body); json(res, { name: saveConfig(filename, content) }); } catch (e) { json(res, { error: e.message }, 400); } });
      return;
    }
    if (u.pathname === '/api/run' && req.method === 'POST') {
      let body = '';
      req.on('data', d => body += d);
      req.on('end', () => { try { runJob(JSON.parse(body)); json(res, { ok: true }); } catch (e) { json(res, { error: e.message }, 400); } });
      return;
    }
    // /file/D:/路徑/檔名.skel：保留副檔名在網址路徑上，pixi 依副檔名判斷格式，atlas 頁圖也能用相對路徑找到
    if (u.pathname.startsWith('/file/')) return sendFile(res, decodeURIComponent(u.pathname.slice(6)));
    if (u.pathname.startsWith('/vendor/')) return sendFile(res, path.join(VENDOR, path.basename(u.pathname)));
    const f = path.join(__dirname, u.pathname === '/' ? 'index.html' : path.normalize(u.pathname).replace(/^([\\/])+/, ''));
    if (!inside(f, __dirname)) { res.writeHead(403); return res.end(); }
    return sendFile(res, f);
  } catch (e) { json(res, { error: e.message }, 500); }
}).listen(PORT, '127.0.0.1', () => console.log(`簡易圖騰動畫產生器：http://localhost:${PORT}`));
