@echo off
rem symbol-anim helper: start the local helper (if not running) and open the online UI
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js not found. Run install.cmd first. & pause & exit /b 1)
if not exist ".venv\Scripts\python.exe" (echo Python env not found. Run install.cmd first. & pause & exit /b 1)
powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing http://127.0.0.1:8810/api/helper -TimeoutSec 1 | Out-Null; exit 0 } catch { exit 1 }"
if errorlevel 1 start "symbol-anim helper" /min node web\server.js 8810
timeout /t 2 /nobreak >nul
rem online UI address comes from deploy.json (uiUrl)
for /f "usebackq delims=" %%u in (`powershell -NoProfile -Command "(Get-Content deploy.json -Raw -Encoding UTF8 | ConvertFrom-Json).uiUrl"`) do set "UIURL=%%u"
if not defined UIURL set "UIURL=http://localhost:8810/"
start "" "%UIURL%"
