簡易圖騰動畫產生器：本機小幫手

線上介面：https://igs-frankhsu01.github.io/symbol-anim-tool/
網頁只是介面；拆圖、做 Spine、輸出都由這個小幫手在你的電腦上呼叫 Photoshop 與 Spine 完成，檔案不會上傳。

需要：Windows、Photoshop、Spine 3.8.99。Node.js、Python、ffmpeg 沒有的話，安裝精靈可以用 winget 自動安裝。

第一次使用（建議用這個 ZIP：Windows Defender 有時會把沒有數位簽章的 exe 安裝檔誤判成病毒擋下）
  1. 把整個資料夾放到固定位置（例如 D:\Tools\symbol-anim-helper），不要放在下載區直接執行。
  2. 雙擊 install.cmd，會開安裝精靈：確認專案根目錄與 Spine 位置，勾選要自動安裝的軟體，按「安裝」。
  3. 完成後桌面會有「簡易圖騰動畫小幫手」捷徑。

之後每次使用
  雙擊桌面捷徑（或 start.cmd）：啟動小幫手並開啟線上介面。
  Chrome／Edge 第一次會問「允許存取區域網路上的裝置」，請按允許。

設定（helper.json，install.cmd 會幫你建）
  workRoot      專案根目錄：丟 PSD 時在這裡找原檔
  spineExe      Spine.com 的位置
  allowOrigins  允許連進小幫手的網址（不寫就是 deploy.json 的線上介面）

部署位置（deploy.json，發放的人設定，使用者不用改）
  uiUrl         線上介面網址；start.cmd 會開這個網址
  workbenchUrl  線上煉丹爐網址
