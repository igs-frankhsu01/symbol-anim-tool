"""從參考影片量縮放曲線，用來做新的動態樣板（templates/anim/*.json）。

在影片裡框一塊只包含單一圖騰的區域，逐格找出跟背景色差異大的像素範圍，輸出寬、高相對「靜止大小」的比例。
靜止大小取前 --rest 格的中位數（影片開頭要是靜止狀態）。

用法：
  .venv\\Scripts\\python.exe utils\\measure_motion.py 影片.mp4 --rect 96,40,152,140 [--fps 30] [--rest 10] [--diff 60]
  輸出 CSV：格,秒,寬,高,寬比例,高比例；再依曲線挑關鍵格寫進樣板。
"""
import argparse, subprocess, sys, tempfile, glob, os
import numpy as np
from PIL import Image

sys.stdout.reconfigure(encoding="utf-8")
ap = argparse.ArgumentParser()
ap.add_argument("video")
ap.add_argument("--rect", required=True, help="x0,y0,x1,y1（影片像素）")
ap.add_argument("--fps", type=float, default=30)
ap.add_argument("--rest", type=int, default=10, help="開頭幾格當靜止大小")
ap.add_argument("--diff", type=float, default=60, help="與背景色的差異門檻（RGB 距離）")
a = ap.parse_args()
x0, y0, x1, y1 = map(int, a.rect.split(","))

with tempfile.TemporaryDirectory() as tmp:
    subprocess.run(["ffmpeg", "-v", "error", "-i", a.video, "-vf", f"fps={a.fps}", os.path.join(tmp, "%04d.png")], check=True)
    rows = []
    for i, f in enumerate(sorted(glob.glob(os.path.join(tmp, "*.png")))):
        im = np.asarray(Image.open(f).convert("RGB")).astype(float)[y0:y1, x0:x1]
        border = np.concatenate([im[0], im[-1], im[:, 0], im[:, -1]])
        bg = np.median(border, axis=0)
        m = np.sqrt(((im - bg) ** 2).sum(-1)) > a.diff
        ys, xs = np.nonzero(m)
        rows.append((i, (xs.max() - xs.min() + 1) if len(xs) else 0, (ys.max() - ys.min() + 1) if len(ys) else 0))

rw = np.median([r[1] for r in rows[:a.rest]]) or 1
rh = np.median([r[2] for r in rows[:a.rest]]) or 1
print("格,秒,寬,高,寬比例,高比例")
for i, w, h in rows:
    print(f"{i},{i / a.fps:.3f},{w},{h},{w / rw:.3f},{h / rh:.3f}")
