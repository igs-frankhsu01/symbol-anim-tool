"""分析圖騰 PSD：列出頂層智慧型物件（每個當一個圖騰候選）與縮圖，給操作網頁產生設定用。

用法：.venv\\Scripts\\python.exe utils\\analyze_psd.py <psd> <縮圖輸出資料夾>
輸出 JSON 到 stdout：{ size, layers: [{ name, occurrence, kind, bbox, w, h, thumb, candidate }] }
"""
import json, os, re, sys
from psd_tools import PSDImage

sys.stdout.reconfigure(encoding="utf-8")
psd_path, out_dir = sys.argv[1:3]
os.makedirs(out_dir, exist_ok=True)
psd = PSDImage.open(psd_path)
seen, layers = {}, []
for idx, l in enumerate(psd):  # 由下往上，與 Photoshop 腳本的同名計數一致
    b = l.bbox
    w, h = b[2] - b[0], b[3] - b[1]
    item = {"name": l.name, "kind": l.kind, "bbox": list(b), "w": w, "h": h, "visible": l.visible, "candidate": False}
    if l.kind == "smartobject":
        seen[l.name] = seen.get(l.name, 0) + 1
        item["occurrence"] = seen[l.name]
        item["candidate"] = w > 0 and h > 0
        if item["candidate"]:
            thumb = os.path.join(out_dir, f"{idx:03d}.png")
            img = l.topil()
            if img is not None:
                img.save(thumb)
                item["thumb"] = thumb
    layers.append(item)
for it in layers:
    it["duplicates"] = seen.get(it["name"], 0) if it["kind"] == "smartobject" else 0
    it["code"] = re.sub(r"[^A-Za-z0-9_]", "", it["name"]) if it["kind"] == "smartobject" else ""
print(json.dumps({"size": list(psd.size), "layers": layers}, ensure_ascii=False))
