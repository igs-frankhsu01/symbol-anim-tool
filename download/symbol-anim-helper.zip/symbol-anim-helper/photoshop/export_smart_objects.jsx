// 圖騰 PSD → 每個指定的頂層智慧型物件打開內容，存一張完整合成 PNG（Photoshop 自己算圖層效果，斜角浮雕、筆畫都正確）。
// run.py 會在這段前面加上 var CFG = { src, out, layers: [{ layer, occurrence, out }] }，路徑一律正斜線、非 ASCII 以 \u 轉義。
// 只開 src（工作副本），結束一律不存檔關閉；使用者開著的其他文件不受影響。
#target photoshop
app.displayDialogs = DialogModes.NO;
app.preferences.rulerUnits = Units.PIXELS;

function q(s) { return '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"'; }

function savePng(doc, path) {
    var o = new PNGSaveOptions();
    o.compression = 6;
    doc.saveAs(new File(path), o, true, Extension.LOWERCASE);
}

// 由下往上數同名智慧型物件，第 occurrence 個（1 起算）；與 psd-tools 的走訪順序一致
function findLayer(doc, name, occurrence) {
    var n = 0;
    for (var i = doc.layers.length - 1; i >= 0; i--) {
        var l = doc.layers[i];
        if (l.typename != "ArtLayer" || l.kind != LayerKind.SMARTOBJECT || l.name != name) continue;
        n++;
        if (n == occurrence) return l;
    }
    return null;
}

var log = [];
var src = app.open(new File(CFG.src));
try {
    for (var k = 0; k < CFG.layers.length; k++) {
        var job = CFG.layers[k];
        var layer = findLayer(src, job.layer, job.occurrence || 1);
        if (!layer) { log.push('{"out":' + q(job.out) + ',"error":"找不到圖層"}'); continue; }
        app.activeDocument = src;
        src.activeLayer = layer;
        executeAction(stringIDToTypeID("placedLayerEditContents"), new ActionDescriptor(), DialogModes.NO);
        var inner = app.activeDocument;
        try {
            var dir = new Folder(CFG.out + "/" + job.out);
            if (!dir.exists) dir.create();
            savePng(inner, CFG.out + "/" + job.out + "/full.png");
            log.push('{"out":' + q(job.out) + ',"w":' + inner.width.as("px") + ',"h":' + inner.height.as("px") + '}');
        } catch (err) {
            log.push('{"out":' + q(job.out) + ',"error":' + q(String(err) + " line " + err.line) + '}');
        }
        inner.close(SaveOptions.DONOTSAVECHANGES);
        // 進度檔：已完成幾個，run.py 讀來回報給操作網頁
        var pf = new File(CFG.out + "/progress.txt");
        pf.open("w"); pf.write(String(k + 1)); pf.close();
    }
} finally {
    src.close(SaveOptions.DONOTSAVECHANGES);
}
var f = new File(CFG.out + "/photoshop_log.json");
f.encoding = "UTF-8";
f.open("w");
f.write("[\n" + log.join(",\n") + "\n]");
f.close();
"done " + log.length;
