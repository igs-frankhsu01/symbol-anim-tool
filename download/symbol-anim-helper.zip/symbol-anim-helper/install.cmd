@echo off
rem symbol-anim helper: setup wizard (installs into this folder)
cd /d "%~dp0"
start "" powershell -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0install.ps1"
