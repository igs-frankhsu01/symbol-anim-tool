@echo off
rem symbol-anim helper: first-time setup (Node.js, Python env, Photoshop/Spine check, helper.json, desktop shortcut)
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
