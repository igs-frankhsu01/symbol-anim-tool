﻿# 簡易圖騰動畫產生器：本機小幫手安裝（由 install.cmd 呼叫）
# 檢查 Node.js、Python、Photoshop、Spine、ffmpeg，建立 Python 環境，寫入 helper.json，建立桌面捷徑。
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
function Say($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Done($ok) { Write-Host ''; Read-Host '按 Enter 關閉' | Out-Null; exit ($(if ($ok) { 0 } else { 1 })) }

Say '簡易圖騰動畫產生器：安裝本機小幫手' 'Cyan'
Say "安裝位置：$here"
Write-Host ''

# 1. Node.js（小幫手本身）
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) {
  Say '✗ 沒有 Node.js。即將開啟下載頁，請安裝 LTS 版，裝好後重新執行 install.cmd。' 'Yellow'
  Start-Process 'https://nodejs.org/zh-tw/download'
  Done $false
}
Say "✓ Node.js $(& node --version)" 'Green'

# 2. Python 3（拆圖、驗證）
function FindPy($cmd, $pre) {
  try {
    $exe = & $cmd @pre -c 'import sys; print(sys.executable)' 2>$null
    if ($LASTEXITCODE -eq 0 -and $exe -and (Test-Path $exe.Trim())) { return $exe.Trim() }
  } catch {}
  return $null
}
$py = FindPy 'py' @('-3')
if (-not $py) { $py = FindPy 'python' @() }
if (-not $py) {
  Say '✗ 沒有 Python 3。即將開啟下載頁，安裝時請勾選「Add python.exe to PATH」，裝好後重新執行 install.cmd。' 'Yellow'
  Start-Process 'https://www.python.org/downloads/windows/'
  Done $false
}
Say "✓ Python：$py" 'Green'

$venvPy = Join-Path $here '.venv\Scripts\python.exe'
if (-not (Test-Path $venvPy)) {
  Say '  建立 Python 環境（.venv）…'
  & $py -m venv (Join-Path $here '.venv')
}
Say '  安裝 psd-tools、numpy、pillow（第一次約 1 分鐘）…'
& $venvPy -m pip install --disable-pip-version-check -q psd-tools numpy pillow
if ($LASTEXITCODE -ne 0) { Say '✗ 套件安裝失敗，請確認網路後重試。' 'Red'; Done $false }
Say '✓ Python 環境完成' 'Green'

# 3. Photoshop
& reg query 'HKCR\Photoshop.Application' *> $null
if ($LASTEXITCODE -eq 0) { Say '✓ Photoshop' 'Green' } else { Say '✗ 找不到 Photoshop：拆圖需要 Photoshop，請先安裝後再使用。' 'Yellow' }

# 4. Spine
$cfgPath = Join-Path $here 'helper.json'
$cfg = @{}
if (Test-Path $cfgPath) { (Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $cfg[$_.Name] = $_.Value } }
$spine = if ($cfg.spineExe) { $cfg.spineExe } else { 'C:\Program Files\Spine\Spine.com' }
while (-not (Test-Path $spine)) {
  $ans = Read-Host "找不到 Spine（$spine）。請貼上 Spine.com 的完整路徑，或直接按 Enter 略過"
  if (-not $ans) { break }
  $spine = $ans.Trim('"')
}
if (Test-Path $spine) { Say "✓ Spine：$spine（需要 3.8.99 版）" 'Green' } else { Say '✗ 沒有設定 Spine：做 Spine 動畫需要 Spine 3.8.99。' 'Yellow' }
$cfg.spineExe = $spine -replace '\\', '/'

# 5. ffmpeg（選用：預覽影片）
if (Get-Command ffmpeg -ErrorAction SilentlyContinue) { Say '✓ ffmpeg' 'Green' }
else {
  $ans = Read-Host '沒有 ffmpeg（只影響預覽影片）。要用 winget 安裝嗎？(Y/N)'
  if ($ans -match '^[Yy]') { & winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements; Say '  裝好後要重新開機或重新登入才會生效' }
}

# 6. 專案根目錄：丟 PSD 時在這裡找原檔
$defRoot = if ($cfg.workRoot) { $cfg.workRoot } else { Split-Path $here -Parent }
$ans = Read-Host "專案根目錄（放各遊戲專案資料夾的地方），直接按 Enter 用 $defRoot"
$cfg.workRoot = ($(if ($ans) { $ans.Trim('"') } else { $defRoot })) -replace '\\', '/'
if (-not $cfg.allowOrigins) { $cfg.allowOrigins = @('https://igs-frankhsu01.github.io') }
[IO.File]::WriteAllText($cfgPath, ($cfg | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
Say "✓ 已寫入 helper.json（專案根目錄 $($cfg.workRoot)）" 'Green'

# 7. 桌面捷徑
$lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) '簡易圖騰動畫小幫手.lnk'
$s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
$s.TargetPath = Join-Path $here 'start.cmd'; $s.WorkingDirectory = $here; $s.WindowStyle = 7; $s.Save()
Say '✓ 桌面已建立「簡易圖騰動畫小幫手」捷徑' 'Green'

Write-Host ''
Say '安裝完成。之後每次使用：雙擊桌面捷徑（或 start.cmd），會啟動小幫手並開啟線上介面。' 'Cyan'
$ans = Read-Host '現在就啟動嗎？(Y/N)'
if ($ans -match '^[Yy]') { Start-Process (Join-Path $here 'start.cmd') -WorkingDirectory $here }
Done $true
