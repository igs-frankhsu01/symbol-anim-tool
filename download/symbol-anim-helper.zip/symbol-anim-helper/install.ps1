﻿# 簡易圖騰動畫產生器：本機小幫手安裝精靈
#   install.cmd 呼叫：裝在這個資料夾（解壓 ZIP 的人用）
#   setup.cmd 呼叫（-Zip，包在 symbol-anim-helper.exe 裡）：先選安裝位置，把 ZIP 解到那裡
# 檢查並代裝 Node.js、Python、ffmpeg（winget），建 Python 環境，寫 helper.json，建桌面捷徑。
param([string]$Zip)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()

$Title = '簡易圖騰動畫小幫手 安裝'
$here = $PSScriptRoot
$fromZip = [bool]$Zip
$hasWinget = [bool](Get-Command winget -ErrorAction SilentlyContinue)

# ---------- 偵測 ----------
function RefreshPath { $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User') }
function FindNode {
  $c = Get-Command node -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  foreach ($p in @("$env:ProgramFiles\nodejs\node.exe", "$env:LOCALAPPDATA\Programs\nodejs\node.exe")) { if (Test-Path $p) { return $p } }
  return $null
}
function TryPy($cmd, $pre) {
  try {
    $exe = & $cmd @pre -c 'import sys; print(sys.executable)' 2>$null
    if ($LASTEXITCODE -eq 0 -and $exe -and (Test-Path $exe.Trim())) { return $exe.Trim() }
  } catch {}
  return $null
}
function FindPy {
  $p = TryPy 'py' @('-3'); if ($p) { return $p }
  $p = TryPy 'python' @(); if ($p) { return $p }
  # winget 剛裝好、PATH 還沒更新時
  $c = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe", "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1
  if ($c) { return $c.FullName }
  return $null
}
function HasPhotoshop { try { & reg query 'HKCR\Photoshop.Application' *> $null; return $LASTEXITCODE -eq 0 } catch { return $false } }
function Exists($p) { $p = "$p".Trim().Trim('"'); return [bool]($p -and (Test-Path -LiteralPath $p)) }
function HasFfmpeg { [bool](Get-Command ffmpeg -ErrorAction SilentlyContinue) }

# 舊設定（重裝、升級時沿用）
function ReadCfg($dir) {
  $h = @{}; $f = Join-Path $dir 'helper.json'
  if (Test-Path $f) { try { (Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $h[$_.Name] = $_.Value } } catch {} }
  return $h
}
$defDir = if ($fromZip) { Join-Path $env:LOCALAPPDATA 'Programs\symbol-anim-helper' } else { $here }
$cfg = ReadCfg $defDir
$defSpine = if ($cfg.spineExe) { $cfg.spineExe -replace '/', '\' } else { 'C:\Program Files\Spine\Spine.com' }
$defRoot = if ($cfg.workRoot) { $cfg.workRoot -replace '/', '\' } elseif (Test-Path 'D:\') { 'D:\' } else { [Environment]::GetFolderPath('MyDocuments') }

# ---------- 視窗 ----------
$font = New-Object Drawing.Font('Microsoft JhengHei UI', 10)
$form = New-Object Windows.Forms.Form
$form.Text = $Title; $form.Font = $font; $form.AutoScaleMode = 'Dpi'
$form.ClientSize = New-Object Drawing.Size(620, 440); $form.FormBorderStyle = 'FixedDialog'; $form.MaximizeBox = $false
$form.StartPosition = 'CenterScreen'; $form.TopMost = $true
$form.Add_Shown({ $form.TopMost = $false; $form.Activate() })

$head = New-Object Windows.Forms.Label
$head.Font = New-Object Drawing.Font('Microsoft JhengHei UI', 13, [Drawing.FontStyle]::Bold)
$head.SetBounds(24, 18, 572, 30)
$sub = New-Object Windows.Forms.Label
$sub.ForeColor = [Drawing.Color]::DimGray; $sub.SetBounds(24, 50, 572, 22)
$line = New-Object Windows.Forms.Label
$line.BorderStyle = 'Fixed3D'; $line.SetBounds(0, 80, 620, 2)
$form.Controls.AddRange(@($head, $sub, $line))

$btnBack = New-Object Windows.Forms.Button; $btnBack.Text = '< 上一步'; $btnBack.SetBounds(310, 392, 92, 32)
$btnNext = New-Object Windows.Forms.Button; $btnNext.Text = '下一步 >'; $btnNext.SetBounds(408, 392, 92, 32)
$btnCancel = New-Object Windows.Forms.Button; $btnCancel.Text = '取消'; $btnCancel.SetBounds(510, 392, 92, 32)
$form.Controls.AddRange(@($btnBack, $btnNext, $btnCancel))
$form.AcceptButton = $btnNext

function NewPage { $p = New-Object Windows.Forms.Panel; $p.SetBounds(24, 92, 572, 290); $p.Visible = $false; $form.Controls.Add($p); return $p }
function AddLabel($page, $text, $x, $y, $w, $h, $color) {
  $l = New-Object Windows.Forms.Label; $l.Text = $text; $l.SetBounds($x, $y, $w, $h)
  if ($color) { $l.ForeColor = $color }
  $page.Controls.Add($l); return $l
}
$green = [Drawing.Color]::FromArgb(30, 130, 70); $red = [Drawing.Color]::FromArgb(190, 60, 40); $gray = [Drawing.Color]::DimGray

# ---- 1 歡迎 ----
$pWelcome = NewPage
AddLabel $pWelcome ("這個精靈會在你的電腦上安裝「本機小幫手」。`n`n" +
  "簡易圖騰動畫產生器的網頁只是操作介面，拆圖、做 Spine 動畫、輸出，都由小幫手呼叫你電腦上的 Photoshop 與 Spine 完成，檔案不會上傳。`n`n" +
  "接下來會：`n" +
  "  • 確認 Photoshop、Spine 3.8.99（要自己先裝好，有授權）`n" +
  "  • 缺 Node.js、Python 的話幫你自動安裝`n" +
  "  • 建立 Python 環境（約 1 分鐘，需要網路）`n" +
  "  • 在桌面建立「簡易圖騰動畫小幫手」捷徑") 0 0 572 280 | Out-Null

# ---- 2 位置 ----
$pPlace = NewPage
function PathRow($page, $y, $label, $hint, $value, $browse) {
  AddLabel $page $label 0 $y 572 22 | Out-Null
  $t = New-Object Windows.Forms.TextBox; $t.SetBounds(0, ($y + 24), 470, 26); $t.Text = $value; $page.Controls.Add($t)
  $b = New-Object Windows.Forms.Button; $b.Text = '瀏覽…'; $b.SetBounds(478, ($y + 22), 94, 30); $page.Controls.Add($b)
  $b.Add_Click($browse)
  AddLabel $page $hint 0 ($y + 54) 572 20 $gray | Out-Null
  return $t
}
function PickFolder($t, $desc) {
  $d = New-Object Windows.Forms.FolderBrowserDialog; $d.Description = $desc; $d.ShowNewFolderButton = $true
  if (Exists $t.Text) { $d.SelectedPath = $t.Text }
  if ($d.ShowDialog($form) -eq 'OK') { $t.Text = $d.SelectedPath }
}
$y = 0
if ($fromZip) {
  $tDir = PathRow $pPlace $y '安裝位置' '小幫手程式放這裡；重裝、更新時選同一個位置，設定會保留。' $defDir { PickFolder $script:tDir '選擇小幫手的安裝位置' }
  $y += 90
}
$tRoot = PathRow $pPlace $y '專案根目錄' '放各遊戲專案資料夾的地方；丟 PSD 時，小幫手在這裡找原檔。' $defRoot { PickFolder $script:tRoot '選擇專案根目錄' }
$y += 90
$tSpine = PathRow $pPlace $y 'Spine 3.8.99 的 Spine.com' '一般在 C:\Program Files\Spine\Spine.com。' $defSpine {
  $d = New-Object Windows.Forms.OpenFileDialog; $d.Title = '選擇 Spine.com'; $d.Filter = 'Spine|Spine.com;Spine.exe|所有檔案|*.*'
  if ($script:tSpine.Text -and (Exists (Split-Path $script:tSpine.Text -Parent))) { $d.InitialDirectory = Split-Path $script:tSpine.Text -Parent }
  if ($d.ShowDialog($form) -eq 'OK') { $script:tSpine.Text = ($d.FileName -replace 'Spine\.exe$', 'Spine.com') }
}

# ---- 3 環境檢查 ----
$pCheck = NewPage
$rows = @{}
$items = @(
  @{ id = 'ps';     name = 'Photoshop';         need = $true;  auto = $false },
  @{ id = 'spine';  name = 'Spine 3.8.99';      need = $true;  auto = $false },
  @{ id = 'node';   name = 'Node.js';           need = $true;  auto = $true; pkg = 'OpenJS.NodeJS.LTS'; url = 'https://nodejs.org/zh-tw/download' },
  @{ id = 'python'; name = 'Python 3';          need = $true;  auto = $true; pkg = 'Python.Python.3.12'; url = 'https://www.python.org/downloads/windows/' },
  @{ id = 'ffmpeg'; name = 'ffmpeg（選用：預覽影片）'; need = $false; auto = $true; pkg = 'Gyan.FFmpeg'; url = 'https://www.gyan.dev/ffmpeg/builds/' }
)
$i = 0
foreach ($it in $items) {
  $yy = $i * 40
  $n = AddLabel $pCheck $it.name 0 ($yy + 4) 210 24
  $s = AddLabel $pCheck '' 214 ($yy + 4) 100 24
  $c = New-Object Windows.Forms.CheckBox; $c.SetBounds(318, ($yy + 2), 254, 28); $c.Visible = $false; $pCheck.Controls.Add($c)
  $h = AddLabel $pCheck '' 318 ($yy + 4) 254 24 $gray
  $rows[$it.id] = @{ item = $it; state = $s; check = $c; hint = $h; ok = $false }
  $i++
}
$checkNote = AddLabel $pCheck '' 0 210 572 46 $gray
$btnRecheck = New-Object Windows.Forms.Button; $btnRecheck.Text = '重新檢查'; $btnRecheck.SetBounds(0, 258, 110, 30); $pCheck.Controls.Add($btnRecheck)

function Mark($id, $ok) {
  $r = $rows[$id]; $r.ok = $ok
  $r.state.Text = if ($ok) { '✓ 已安裝' } elseif ($r.item.need) { '✗ 沒有' } else { '— 沒有' }
  $r.state.ForeColor = if ($ok) { $green } elseif ($r.item.need) { $red } else { $gray }
  $r.offer = $false; $r.check.Visible = $false; $r.hint.Visible = $false
  if ($ok) { return }
  if ($r.item.auto -and $hasWinget) {
    $r.check.Text = '幫我自動安裝'; $r.check.Checked = $r.item.need; $r.check.Visible = $true; $r.offer = $true
  } elseif ($r.item.auto) {
    $r.hint.Text = '請到官網下載安裝後按「重新檢查」'; $r.hint.Visible = $true
  } elseif ($id -eq 'ps') {
    $r.hint.Text = '請先安裝（拆圖會用到）'; $r.hint.Visible = $true
  } else {
    $r.hint.Text = '請回上一步選 Spine.com 位置'; $r.hint.Visible = $true
  }
}
function RunCheck {
  $form.Cursor = 'WaitCursor'
  RefreshPath
  Mark 'ps' (HasPhotoshop)
  Mark 'spine' (Exists $tSpine.Text)
  Mark 'node' ([bool](FindNode))
  Mark 'python' ([bool](FindPy))
  Mark 'ffmpeg' (HasFfmpeg)
  $form.Cursor = 'Default'
  $miss = @($rows.Values | Where-Object { $_.item.need -and -not $_.ok -and -not $_.offer })
  $checkNote.Text = if ($miss.Count) { '有缺少的軟體仍可以繼續安裝，但補齊之前產生器會無法執行對應步驟。自動安裝 Node.js 時 Windows 可能會問「是否允許變更」，請按「是」。' }
                    else { '按「安裝」開始。自動安裝 Node.js 時 Windows 可能會問「是否允許變更」，請按「是」。' }
}
$btnRecheck.Add_Click({ RunCheck })

# ---- 4 安裝中 ----
$pWork = NewPage
$bar = New-Object Windows.Forms.ProgressBar; $bar.SetBounds(0, 0, 572, 20); $bar.Style = 'Marquee'; $pWork.Controls.Add($bar)
$log = New-Object Windows.Forms.TextBox; $log.Multiline = $true; $log.ScrollBars = 'Vertical'; $log.ReadOnly = $true
$log.Font = New-Object Drawing.Font('Consolas', 9); $log.SetBounds(0, 30, 572, 258); $pWork.Controls.Add($log)
function Log($t) { $log.AppendText($t + "`r`n"); [Windows.Forms.Application]::DoEvents() }
# --source winget：公司網路會擋 msstore 來源的憑證，整個指令就失敗
# 跑外部程式時視窗不會卡住：輸出寫到暫存檔，邊等邊顯示
function Run($exe, [string[]]$argv) {
  $out = [IO.Path]::GetTempFileName()
  $q = { param($s) if ($s -match '[\s"]') { '"' + ($s -replace '"', '\"') + '"' } else { $s } }
  $cmdline = '"' + $exe + '" ' + (($argv | ForEach-Object { & $q $_ }) -join ' ') + ' > "' + $out + '" 2>&1'
  $p = Start-Process cmd.exe -ArgumentList '/d', '/s', '/c', ('"' + $cmdline + '"') -WindowStyle Hidden -PassThru
  $seen = 0
  while (-not $p.HasExited) {
    Start-Sleep -Milliseconds 150; [Windows.Forms.Application]::DoEvents()
    $seen = Flush $out $seen
  }
  $p.WaitForExit(); Flush $out $seen | Out-Null
  Remove-Item $out -ErrorAction SilentlyContinue
  return $p.ExitCode
}
function Flush($file, $seen) {
  try {
    $all = [IO.File]::ReadAllText($file, [Text.Encoding]::Default)
    if ($all.Length -gt $seen) {
      # 進度條字元（\r、轉圈）只留最後一段
      foreach ($l in ($all.Substring($seen) -split "`n")) { $l = ($l -split "`r")[-1].TrimEnd(); if ($l -and $l -notmatch '^[\s\-\\|/█▒]+$') { Log ('  ' + $l) } }
      return $all.Length
    }
  } catch {}
  return $seen
}

# ---- 5 完成 ----
$pDone = NewPage
$doneText = AddLabel $pDone '' 0 0 572 200
$chkStart = New-Object Windows.Forms.CheckBox; $chkStart.Text = '現在就啟動小幫手並開啟產生器'; $chkStart.Checked = $true; $chkStart.SetBounds(0, 210, 572, 28); $pDone.Controls.Add($chkStart)

# ---------- 安裝 ----------
$script:ok = $false; $script:dir = $here
function Install {
  $warn = @()
  try {
    $dir = if ($fromZip) { $tDir.Text.Trim('"').TrimEnd('\') } else { $here }
    $script:dir = $dir

    if ($fromZip) {
      Log "解壓縮到 $dir"
      $tmp = Join-Path $env:TEMP ('symbol-anim-' + [guid]::NewGuid().ToString('N'))
      New-Item -ItemType Directory -Force $tmp | Out-Null
      Expand-Archive -LiteralPath $Zip -DestinationPath $tmp -Force
      New-Item -ItemType Directory -Force $dir | Out-Null
      # 覆蓋程式檔；helper.json、configs、.venv 保留
      Copy-Item -Path (Join-Path $tmp 'symbol-anim-helper\*') -Destination $dir -Recurse -Force
      Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
      Log '✓ 程式檔完成'
    }

    foreach ($id in 'node', 'python', 'ffmpeg') {
      $r = $rows[$id]
      if ($r.ok -or -not $r.offer -or -not $r.check.Checked) { continue }
      Log "安裝 $($r.item.name)（winget，約 1～3 分鐘）…"
      $argv = @('install', '-e', '--id', $r.item.pkg, '--source', 'winget', '--silent', '--accept-source-agreements', '--accept-package-agreements', '--disable-interactivity')
      if ($id -eq 'python') { $argv += @('--scope', 'user', '--override', '/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1') }
      $code = Run 'winget' $argv
      RefreshPath
      if ($code -ne 0 -and -not ($id -eq 'node' -and (FindNode)) -and -not ($id -eq 'python' -and (FindPy)) -and -not ($id -eq 'ffmpeg' -and (HasFfmpeg))) {
        $warn += "$($r.item.name) 自動安裝沒有成功（代碼 $code），請到 $($r.item.url) 手動安裝"
        Log "✗ $($r.item.name) 安裝失敗"
      } else { Log "✓ $($r.item.name)" }
    }

    $node = FindNode
    if (-not $node) { $warn += 'Node.js 沒有安裝：小幫手無法啟動，請安裝後重新執行安裝程式' }
    $py = FindPy
    if ($py) {
      Log "Python：$py"
      $venvPy = Join-Path $dir '.venv\Scripts\python.exe'
      if (-not (Test-Path $venvPy)) {
        Log '建立 Python 環境（.venv）…'
        Run $py @('-m', 'venv', (Join-Path $dir '.venv')) | Out-Null
      }
      Log '安裝 psd-tools、numpy、pillow（第一次約 1 分鐘）…'
      $code = Run $venvPy @('-m', 'pip', 'install', '--disable-pip-version-check', '-q', 'psd-tools', 'numpy', 'pillow', 'scipy')
      if ($code -eq 0) { Log '✓ Python 環境完成' } else { $warn += 'Python 套件安裝失敗：請確認網路後重新執行安裝程式'; Log '✗ Python 套件安裝失敗' }
    } else { $warn += 'Python 沒有安裝：拆圖與驗證無法執行，請安裝後重新執行安裝程式' }

    $c = ReadCfg $dir
    $c.workRoot = $tRoot.Text.Trim('"') -replace '\\', '/'
    $c.spineExe = $tSpine.Text.Trim('"') -replace '\\', '/'
    if ($node) { $c.node = $node -replace '\\', '/' }
    # 允許連進來的網址不寫：預設就是 deploy.json 的線上介面，換主機只改 deploy.json
    [IO.File]::WriteAllText((Join-Path $dir 'helper.json'), ($c | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
    Log "✓ 已寫入 helper.json"

    $lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) '簡易圖騰動畫小幫手.lnk'
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
    $s.TargetPath = Join-Path $dir 'start.cmd'; $s.WorkingDirectory = $dir; $s.WindowStyle = 7
    $s.IconLocation = "$env:SystemRoot\System32\shell32.dll,137"; $s.Save()
    Log '✓ 桌面捷徑「簡易圖騰動畫小幫手」'
    if (-not (HasPhotoshop)) { $warn += '找不到 Photoshop：拆圖前請先安裝' }
    if (-not (Exists $tSpine.Text)) { $warn += '沒有設定 Spine：做動畫前請安裝 Spine 3.8.99，再重新執行安裝程式選位置' }
    $script:ok = [bool]$node
  } catch {
    Log ('✗ ' + $_.Exception.Message); $warn += '安裝中斷：' + $_.Exception.Message
  }
  $bar.Style = 'Blocks'; $bar.Value = 100
  $doneText.Text = if ($script:ok -and -not $warn.Count) {
    "安裝完成。`n`n之後每次使用：雙擊桌面「簡易圖騰動畫小幫手」，會啟動小幫手並開啟產生器網頁。`n`nChrome／Edge 第一次會問「允許存取區域網路上的裝置」，請按「允許」。`n`n安裝位置：$($script:dir)"
  } else {
    "安裝完成，但有以下事項要處理：`n`n" + (($warn | ForEach-Object { '• ' + $_ }) -join "`n") + "`n`n處理好後再執行一次安裝程式即可，設定會保留。"
  }
  $doneText.ForeColor = if ($warn.Count) { $red } else { [Drawing.SystemColors]::ControlText }
  $chkStart.Visible = $script:ok; $chkStart.Checked = $script:ok
  $btnNext.Enabled = $true
}

# ---------- 換頁 ----------
$pages = @(
  @{ p = $pWelcome; h = '歡迎'; s = '安裝簡易圖騰動畫產生器的本機小幫手' },
  @{ p = $pPlace;   h = '選擇位置'; s = '可以直接用預設值' },
  @{ p = $pCheck;   h = '確認軟體'; s = '打勾的項目會自動安裝' },
  @{ p = $pWork;    h = '安裝中'; s = '請稍候，不要關閉視窗' },
  @{ p = $pDone;    h = '完成'; s = '' }
)
$script:at = 0
function GoTo($n) {
  $script:at = $n
  for ($k = 0; $k -lt $pages.Count; $k++) { $pages[$k].p.Visible = ($k -eq $n) }
  $head.Text = $pages[$n].h; $sub.Text = $pages[$n].s
  $btnBack.Enabled = ($n -in 1, 2)
  $btnNext.Text = switch ($n) { 2 { '安裝' } 4 { '完成' } default { '下一步 >' } }
  $btnCancel.Enabled = ($n -ne 3); $btnNext.Enabled = ($n -ne 3)
  if ($n -eq 2) { RunCheck }
  if ($n -eq 3) { $form.Refresh(); Install; GoTo 4 }
}
$btnBack.Add_Click({ GoTo ($script:at - 1) })
$btnCancel.Add_Click({ $form.Close() })
$btnNext.Add_Click({
  if ($script:at -eq 1) {
    $err = @()
    if ($fromZip -and -not $tDir.Text.Trim()) { $err += '請選擇安裝位置' }
    if (-not (Exists $tRoot.Text)) { $err += '專案根目錄不存在' }
    if ($err.Count) { [Windows.Forms.MessageBox]::Show($form, ($err -join "`n"), $Title, 'OK', 'Warning') | Out-Null; return }
  }
  if ($script:at -eq 4) {
    if ($chkStart.Checked) { Start-Process (Join-Path $script:dir 'start.cmd') -WorkingDirectory $script:dir -WindowStyle Minimized }
    $form.Close(); return
  }
  GoTo ($script:at + 1)
})
$form.Add_FormClosing({ param($s, $e) if ($script:at -eq 3) { $e.Cancel = $true } })

GoTo 0
[void]$form.ShowDialog()
