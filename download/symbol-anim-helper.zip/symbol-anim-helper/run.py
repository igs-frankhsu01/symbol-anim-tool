"""簡易圖騰動畫產生器（雛型）：設定檔驅動，從圖騰 PSD 一路做到 Spine 交付檔與驗證。

步驟（可用 --steps 只跑其中幾步，依序執行）：
  photoshop  Photoshop 打開每個智慧型物件，存出完整合成圖（圖層效果由 Photoshop 自己算）
  textures   依外層 PSD 的變形框把合成圖縮成設計稿 1:1 貼圖，算出骨頭位置
  spine      產生每個圖騰一個 Skeleton 的 JSON（套動態樣板，可含偽 3D 與參數），匯入成同一個 .spine
  size       確認尺寸（輸出前）：反向匯出查 root 與動畫長度，Spine 實際算圖量尺寸，跟 PSD×輸出縮放比對
  export     依打包設定輸出 .skel／.atlas／.png
  verify     驗證（輸出後）：交付檔齊全、圖集區域＝遊戲像素，寫完整報告
  preview    各圖騰並排的預覽影片（與動態圖）
  showcase   把 Spine 登記到煉丹爐展示台的 assets.json

用法：
  .venv\\Scripts\\python.exe run.py configs\\dancingdrums_main.json
  .venv\\Scripts\\python.exe run.py configs\\dancingdrums_main.json --steps verify,preview
  .venv\\Scripts\\python.exe run.py configs\\dancingdrums_main.json --spine-dir D:/tmp/test   # 輸出到別處試跑
"""
import argparse, ast, datetime, glob, json, os, re, shutil, subprocess, sys, time
import numpy as np
from PIL import Image

sys.stdout.reconfigure(encoding="utf-8")
TOOL = os.path.dirname(os.path.abspath(__file__))
STEPS = ["photoshop", "textures", "spine", "size", "export", "verify", "preview", "showcase"]


# ---------- 設定 ----------
class Ctx:
    def __init__(self, cfg_path, spine_dir=None, force=False):
        self.cfg_path = os.path.abspath(cfg_path)
        self.cfg = json.load(open(cfg_path, encoding="utf-8"))
        c = self.cfg
        self.root = c["root"]
        self.psd = self.path(c["psd"])
        self.spine_dir = spine_dir or self.path(c["spine"]["dir"])
        self.spine_name = c["spine"].get("name") or os.path.basename(self.spine_dir.rstrip("/\\"))
        self.spine_file = os.path.join(self.spine_dir, self.spine_name + ".spine")
        self.work = os.path.join(TOOL, "work", os.path.splitext(os.path.basename(cfg_path))[0])
        self.scale = c["output"]["scale"]
        self.texture_scale = c.get("textureScale", 1.0)  # 貼圖相對設計稿的倍數（2 = 兩倍大製作）
        self.root_scale = round(self.scale / self.texture_scale, 6)  # root 與打包縮放同值（R-9.4）
        self.anim = c["animation"]
        self.force = force
        self.trial = spine_dir is not None  # 試跑：不寫說明書動態圖、不登記展示台
        self.stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        os.makedirs(self.work, exist_ok=True)

    def path(self, p):
        return p if os.path.isabs(p) else os.path.join(self.root, p)

    def name(self, kind, sym):
        fmt = self.cfg["naming"][kind]
        return fmt.format(project=self.cfg["project"], code=sym["code"])

    @property
    def symbols(self):
        return self.cfg["symbols"]

    def skel(self, sym):
        return self.name("skeleton", sym)

    def wpath(self, *p):
        return os.path.join(self.work, *p)


def tpl(*p):
    return json.load(open(os.path.join(TOOL, "templates", *p), encoding="utf-8"))


def run(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", **kw)
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def progress(step, done, total, label=""):
    """給操作網頁看的進度行：done＝已完成幾項、label＝正在處理的項目。"""
    print("@@" + json.dumps({"step": step, "done": done, "total": total, "label": label}, ensure_ascii=False), flush=True)


def spine_cli(ctx, *args):
    sp = ctx.cfg["spine"]
    code, out = run([sp.get("exe", "C:/Program Files/Spine/Spine.com"), "-u", sp.get("version", "3.8.99"), *args])
    if code or "ERROR" in out or "Complete." not in out:
        raise RuntimeError("Spine 指令失敗：\n" + out[-1500:])
    return out


def backup(ctx, path):
    if not os.path.exists(path):
        return
    dst = ctx.wpath("backup", ctx.stamp, os.path.basename(path))
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.move(path, dst)
    print(f"  已備份 {path} → {dst}")


def spine_editor_has(ctx):
    code, out = run(["powershell", "-NoProfile", "-Command",
                     "Get-Process Spine* -ErrorAction SilentlyContinue | ForEach-Object { $_.MainWindowTitle }"])
    return any(ctx.spine_name in line for line in out.splitlines())


# ---------- photoshop ----------
def step_photoshop(ctx):
    copy = ctx.wpath("psd_copy" + os.path.splitext(ctx.psd)[1])
    shutil.copy2(ctx.psd, copy)  # 只操作副本
    out = ctx.wpath("photoshop")
    os.makedirs(out, exist_ok=True)
    cfg = {"src": copy.replace("\\", "/"), "out": out.replace("\\", "/"),
           "layers": [{"layer": s["layer"], "occurrence": s.get("occurrence", 1), "out": s["code"]} for s in ctx.symbols]}
    body = open(os.path.join(TOOL, "photoshop", "export_smart_objects.jsx"), encoding="utf-8").read()
    jsx = ctx.wpath("run_export.jsx")
    open(jsx, "w", encoding="utf-8").write("var CFG = " + json.dumps(cfg, ensure_ascii=True) + ";\n" + body)
    # Photoshop 每存完一個圖騰就寫 progress.txt，這裡邊等邊回報進度
    prog = os.path.join(out, "progress.txt")
    if os.path.exists(prog):
        os.remove(prog)
    n = len(ctx.symbols)
    progress("photoshop", 0, n, ctx.symbols[0]["code"])
    p = subprocess.Popen(["powershell", "-NoProfile", "-Command",
                          f"$ps = New-Object -ComObject Photoshop.Application; $ps.DoJavaScriptFile('{jsx}')"],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    seen = 0
    while p.poll() is None:
        try:
            done = int(open(prog, encoding="utf-8").read().split()[0])
        except (OSError, ValueError, IndexError):
            done = seen
        if done != seen:
            seen = done
            progress("photoshop", done, n, ctx.symbols[min(done, n - 1)]["code"])
        time.sleep(0.3)
    msg = p.stdout.read()
    if p.returncode:
        raise RuntimeError("Photoshop 執行失敗：" + msg)
    progress("photoshop", n, n)
    log = json.load(open(os.path.join(out, "photoshop_log.json"), encoding="utf-8"))
    bad = [l for l in log if "error" in l]
    if bad:
        raise RuntimeError(f"Photoshop 有圖層失敗：{bad}")
    print(f"  Photoshop 存出 {len(log)} 張合成圖 → {out}")


# ---------- textures ----------
def find_layers(psd_path, symbols):
    from psd_tools import PSDImage
    psd = PSDImage.open(psd_path)
    found = {}
    for s in symbols:
        n = 0
        for l in psd:  # 由下往上，與 jsx 相同
            if l.kind == "smartobject" and l.name == s["layer"]:
                n += 1
                if n == s.get("occurrence", 1):
                    found[s["code"]] = l
                    break
        if s["code"] not in found:
            raise RuntimeError(f"PSD 找不到圖層 {s['layer']}（第 {s.get('occurrence', 1)} 個）")
    return psd.size, found


def step_textures(ctx):
    copy = ctx.wpath("psd_copy" + os.path.splitext(ctx.psd)[1])
    (cw, ch), layers = find_layers(copy if os.path.exists(copy) else ctx.psd, ctx.symbols)
    k = ctx.texture_scale
    info = {}
    for idx, s in enumerate(ctx.symbols):
        progress("textures", idx, len(ctx.symbols), s["code"])
        l = layers[s["code"]]
        src = Image.open(ctx.wpath("photoshop", s["code"], "full.png")).convert("RGBA")
        tb = l.smart_object.transform_box
        left, top = tb[0] * k, tb[1] * k
        tw, th = (tb[2] - tb[0]) * k, (tb[5] - tb[1]) * k
        # 取整數像素格線，小數位移用來源外擴補足，只重取樣一次
        ox, oy = int(np.floor(left)), int(np.floor(top))
        kx, ky = src.width / tw, src.height / th
        pad = 32
        padded = Image.new("RGBA", (src.width + pad * 2, src.height + pad * 2))
        padded.paste(src, (pad, pad))
        out_w, out_h = int(np.ceil(tw + left - ox)) + 1, int(np.ceil(th + top - oy)) + 1
        bx0, by0 = pad - (left - ox) * kx, pad - (top - oy) * ky
        sized = padded.resize((out_w, out_h), Image.LANCZOS, box=(bx0, by0, bx0 + out_w * kx, by0 + out_h * ky))
        # LANCZOS 縮小在外圍留下 alpha≈4 的振鈴殘影，原圖沒有，清掉以免多出空白邊
        arr = np.asarray(sized).copy()
        arr[arr[..., 3] < 8] = 0
        ys, xs = np.nonzero(arr[..., 3])
        x0, y0, x1, y1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
        img = Image.fromarray(arr, "RGBA").crop((x0, y0, x1, y1))
        w, h = img.size
        skel = ctx.skel(s)
        img_dir = os.path.join(ctx.spine_dir, "Images", skel)
        os.makedirs(img_dir, exist_ok=True)
        img.save(os.path.join(img_dir, ctx.name("image", s) + ".png"))
        # 以 PSD 畫布中心為 0,0（Symbol 靜態圖置中）；Spine y 向上
        bx = round(ox + x0 + w / 2 - cw * k / 2, 2)
        by = round(ch * k / 2 - (oy + y0 + h / 2), 2)
        b = l.bbox
        info[s["code"]] = {"skeleton": skel, "image": ctx.name("image", s), "size": [w, h], "bone": [bx, by],
                           "psdBox": [b[2] - b[0], b[3] - b[1]]}
        print(f"  {skel}: 貼圖 {w}×{h}（PSD {b[2] - b[0]}×{b[3] - b[1]}），骨頭 {bx},{by}")
    json.dump(info, open(ctx.wpath("textures.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    progress("textures", len(ctx.symbols), len(ctx.symbols))


# ---------- spine ----------
# 動態樣板：params 宣告可調參數；keys（縮放）與 tilt.keys（偽 3D 角度 [格, 左右, 前後, 曲線]）的格數、數值可寫算式，
# 角度也可以分軌寫成 tilt.ry／tilt.rx（[格, 角度, 曲線]，Timeline 編輯器存的自訂樣板用這種）；曲線可寫 curves 裡的名稱或直接 [cx1, cy1, cx2, cy2]。
# {"repeat": 次數, "keys": [...]} 會展開成多組（算式裡可用 i = 0, 1, …）。網頁（web/server.js expandTemplate）用同一套規則。
EXPR_FUNCS = {"max": max, "min": min, "abs": abs, "round": lambda x: int(np.floor(x + 0.5)), "int": int}
EXPR_NODES = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Constant, ast.Name, ast.Load, ast.Call, ast.operator, ast.unaryop)


def expr(v, env):
    if not isinstance(v, str):
        return v
    tree = ast.parse(v, mode="eval")
    bad = [type(n).__name__ for n in ast.walk(tree) if not isinstance(n, EXPR_NODES)]
    if bad:
        raise ValueError(f"樣板算式只能用四則運算與 {'、'.join(EXPR_FUNCS)}：{v}")
    return eval(compile(tree, "<樣板>", "eval"), {"__builtins__": {}, **EXPR_FUNCS}, env)


def expand_keys(keys, env, nvals):
    out = []
    for k in keys:
        if isinstance(k, dict):
            for i in range(int(expr(k["repeat"], env))):
                out += expand_keys(k["keys"], {**env, "i": i}, nvals)
        else:
            out.append([int(round(expr(k[0], env)))] + [round(float(expr(v, env)), 4) for v in k[1:1 + nvals]] + [k[1 + nvals] if len(k) > 1 + nvals else None])
    return out


def load_template(name, params=None):
    """讀動態樣板並代入參數（未填的用預設值），回傳展開後的樣板（keys、tilt.ry、tilt.rx 都是數字 [格, 值, 曲線]）。"""
    t = tpl("anim", name + ".json")
    env = {p["key"]: p["default"] for p in t.get("params", [])}
    env.update({k: v for k, v in (params or {}).items() if k in env})
    t["values"] = dict(env)
    t["keys"] = expand_keys(t["keys"], env, 1)
    if t.get("tilt"):
        tl = t["tilt"]
        if "keys" in tl:
            ks = expand_keys(tl.pop("keys"), env, 2)
            tl["ry"], tl["rx"] = [[k[0], k[1], k[3]] for k in ks], [[k[0], k[2], k[3]] for k in ks]
        else:
            for a in ("ry", "rx"):
                tl[a] = expand_keys(tl.get(a) or [[0, 0, None]], env, 1)
        for k in ("perspective", "shade"):
            if k in tl:
                tl[k] = float(expr(tl[k], env))
    tracks = [[k[0] for k in ks] for ks in [t["keys"]] + ([t["tilt"]["ry"], t["tilt"]["rx"]] if t.get("tilt") else [])]
    if any(b < a for fs in tracks for a, b in zip(fs, fs[1:])):
        raise ValueError(f"樣板 {name} 的參數讓關鍵格順序顛倒了，請調整格數類參數")
    t["length"] = max(fs[-1] for fs in tracks)
    return t


def anim_keys(ctx):
    t = load_template(ctx.anim["template"], ctx.anim.get("params"))
    fps = ctx.anim.get("fps", t.get("fps", 30))
    keys = []
    for f, v, curve in t["keys"]:
        k = {"time": round(f / fps, 4), "x": v, "y": v}
        if curve:
            c = t["curves"][curve] if isinstance(curve, str) else curve
            k.update({"curve": c[0], "c2": c[1], "c3": c[2], "c4": c[3]})
        keys.append(k)
    if t["length"] > t["keys"][-1][0]:  # 縮放比角度先結束：補一格讓動畫長度一致
        keys.append({"time": round(t["length"] / fps, 4), "x": t["keys"][-1][1], "y": t["keys"][-1][1]})
    return t, keys


# ---------- 偽 3D：整張圖改成網格 Mesh，逐格把頂點做透視投影（Spine deform 是線性內插，所以逐格烘焙） ----------
def bezier_at(c, u):
    """Spine 曲線 [cx1, cy1, cx2, cy2]：給時間比例 u 回傳數值比例。"""
    lo, hi = 0.0, 1.0
    for _ in range(40):
        t = (lo + hi) / 2
        x = 3 * (1 - t) ** 2 * t * c[0] + 3 * (1 - t) * t * t * c[2] + t ** 3
        lo, hi = (t, hi) if x < u else (lo, t)
    t = (lo + hi) / 2
    return 3 * (1 - t) ** 2 * t * c[1] + 3 * (1 - t) * t * t * c[3] + t ** 3


def track_at(keys, curves, frame):
    """單軌 [格, 值, 曲線] 在第 frame 格的值。"""
    if frame >= keys[-1][0]:
        return keys[-1][1]
    for a, b in zip(keys, keys[1:]):
        if a[0] <= frame < b[0]:
            u = (frame - a[0]) / (b[0] - a[0])
            if a[2]:
                u = bezier_at(curves[a[2]] if isinstance(a[2], str) else a[2], u)
            return a[1] + (b[1] - a[1]) * u
    return keys[0][1]


def tilt_angles(t, frame):
    """第 frame 格的 (ry, rx) 角度（度）。"""
    tl = t["tilt"]
    return track_at(tl["ry"], t["curves"], frame), track_at(tl["rx"], t["curves"], frame)


def tilt_mesh(w, h, grid):
    """矩形網格 Mesh：外框頂點依序排在前面（hull），中心為 0,0。回傳頂點座標 (n,2)、uvs、triangles、hull 數。"""
    gx, gy = grid
    border = [(i, 0) for i in range(gx)] + [(gx, j) for j in range(gy)] + [(i, gy) for i in range(gx, 0, -1)] + [(0, j) for j in range(gy, 0, -1)]
    inner = [(i, j) for j in range(1, gy) for i in range(1, gx)]
    order = border + inner
    idx = {p: n for n, p in enumerate(order)}
    pts = np.array([(-w / 2 + w * i / gx, h / 2 - h * j / gy) for i, j in order])
    uvs = [round(v, 6) for i, j in order for v in (i / gx, j / gy)]
    tris = []
    for j in range(gy):
        for i in range(gx):
            a, b, c, d = idx[(i, j)], idx[(i + 1, j)], idx[(i + 1, j + 1)], idx[(i, j + 1)]
            tris += [a, b, c, a, c, d]
    return pts, uvs, tris, len(border)


def tilt_project(pts, ry, rx, dist):
    """先繞 Y 軸（左右轉，正值右緣朝向觀眾）再繞 X 軸（正值上緣往後仰），再依距離 dist 做透視。回傳投影座標與朝光亮度比。"""
    a, b = np.radians(ry), np.radians(rx)
    x, y, z = pts[:, 0] * np.cos(a), pts[:, 1], pts[:, 0] * np.sin(a)
    y, z = y * np.cos(b) - z * np.sin(b), y * np.sin(b) + z * np.cos(b)
    s = dist / (dist - z)
    n = np.array([-np.sin(a), -np.sin(b) * np.cos(a), np.cos(b) * np.cos(a)])  # 面的法線
    light = np.array([-0.35, 0.45, 1.0])  # 光從左上前方來
    return np.stack([x * s, y * s], 1), float(n @ light / light[2])


def tilt_build(ctx, t, w, h, slot, image):
    """回傳 (attachment, animation 追加內容)；樣板沒有 tilt 時回傳 None。"""
    tl = t.get("tilt")
    if not tl:
        return None
    pts, uvs, tris, hull = tilt_mesh(w, h, tl.get("grid", [8, 8]))
    dist = tl.get("perspective", 2.2) * max(w, h)
    shade = tl.get("shade", 0)
    fps = ctx.anim.get("fps", t.get("fps", 30))
    deform, colors = [], []
    for f in range(t["length"] + 1):
        ry, rx = tilt_angles(t, f)
        proj, lit = tilt_project(pts, ry, rx, dist)
        k = {"time": round(f / fps, 4)}
        d = (proj - pts).ravel()
        if np.abs(d).max() > 1e-4:
            k["vertices"] = [round(float(v), 3) for v in d]
        deform.append(k)
        v = int(round(255 * min(1.0, 1 - shade * (1 - lit))))
        colors.append({"time": k["time"], "color": f"{v:02x}{v:02x}{v:02x}ff"})
    att = {"type": "mesh", "uvs": uvs, "triangles": tris, "vertices": [round(float(v), 3) for v in pts.ravel()], "hull": hull,
           "edges": [n for i in range(hull) for n in (i * 2, (i + 1) % hull * 2)], "width": w, "height": h}
    anim = {"deform": {"default": {slot: {image: deform}}}}
    if shade:
        anim["slots"] = {slot: {"color": colors}}
    return att, anim


def step_spine(ctx):
    if spine_editor_has(ctx) and not ctx.force:
        raise RuntimeError(f"Spine 編輯器正開著 {ctx.spine_name}：請先關閉該專案再跑（或加 --force，之後別在舊視窗存檔）")
    info = json.load(open(ctx.wpath("textures.json"), encoding="utf-8"))
    t, keys = anim_keys(ctx)
    bone = ctx.cfg["naming"].get("bone", "Main")
    jdir = ctx.wpath("spine_json")
    os.makedirs(jdir, exist_ok=True)
    for s in ctx.symbols:
        i = info[s["code"]]
        w, h = i["size"]
        bx, by = i["bone"]
        data = {
            "skeleton": {"hash": "", "spine": ctx.cfg["spine"].get("version", "3.8.99"), "x": -w / 2 + bx, "y": -h / 2 + by,
                         "width": w, "height": h, "images": f"./Images/{i['skeleton']}/", "audio": ""},
            "bones": [
                {"name": "root", "scaleX": ctx.root_scale, "scaleY": ctx.root_scale} if ctx.root_scale != 1 else {"name": "root"},
                {"name": "Actor", "parent": "root"},
                {"name": bone, "parent": "Actor", "x": bx, "y": by},
            ],
            "slots": [{"name": bone, "bone": bone, "attachment": i["image"]}],
            "skins": [{"name": "default", "attachments": {bone: {i["image"]: {"width": w, "height": h}}}}],
            "animations": {ctx.anim["name"]: {"bones": {bone: {t.get("property", "scale"): keys}}}},
        }
        fx = tilt_build(ctx, t, w, h, bone, i["image"])
        if fx:
            data["skins"][0]["attachments"][bone][i["image"]] = fx[0]
            data["animations"][ctx.anim["name"]].update(fx[1])
        json.dump(data, open(os.path.join(jdir, i["skeleton"] + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    backup(ctx, ctx.spine_file)
    os.makedirs(ctx.spine_dir, exist_ok=True)
    # JSON 的 images 路徑相對於 JSON 本身，所以暫放在專案資料夾匯入，匯入後移回工作區
    for idx, s in enumerate(ctx.symbols):
        progress("spine", idx, len(ctx.symbols), s["code"])
        sk = info[s["code"]]["skeleton"]
        tmp = os.path.join(ctx.spine_dir, sk + ".json")
        shutil.copy2(os.path.join(jdir, sk + ".json"), tmp)
        try:
            spine_cli(ctx, "-i", tmp, "-o", ctx.spine_file, "--to", sk, "-r")
        finally:
            os.remove(tmp)
    progress("spine", len(ctx.symbols), len(ctx.symbols))
    vals = "、".join(f"{p['label']} {t['values'][p['key']]}" for p in t.get("params", []))
    print(f"  已建立 {ctx.spine_file}（{len(ctx.symbols)} 個 Skeleton，root {ctx.root_scale}，{ctx.anim['name']} {keys[-1]['time']} 秒，"
          f"樣板 {ctx.anim['template']}{'（偽 3D）' if t.get('tilt') else ''}{'：' + vals if vals else ''}）")


# ---------- export ----------
def step_export(ctx):
    ex = ctx.cfg.get("export", {})
    st = tpl("spine", "export_binary.json")
    st["packTarget"] = ex.get("packTarget", "all")
    st["packAtlas"]["scale"] = [ctx.root_scale]
    path = ctx.wpath("export_settings.json")
    json.dump(st, open(path, "w", encoding="utf-8"), indent=1)
    out = os.path.join(ctx.spine_dir, "Export")
    if os.path.isdir(out) and os.listdir(out):
        backup(ctx, out)
    os.makedirs(out, exist_ok=True)
    progress("export", 0, 1, "打包")
    spine_cli(ctx, "-i", ctx.spine_file, "-o", out, "-e", path)
    progress("export", 1, 1)
    print(f"  已輸出 → {out}：{', '.join(sorted(os.listdir(out)))}")


# ---------- verify ----------
def atlas_regions(out_dir):
    regions = {}
    for a in glob.glob(os.path.join(out_dir, "*.atlas")):
        for m in re.finditer(r"\n(\S[^\n]*)\n  rotate: \w+\n  xy: \d+, \d+\n  size: (\d+), (\d+)", open(a, encoding="utf-8").read()):
            regions[m.group(1)] = (int(m.group(2)), int(m.group(3)))
    return regions


def key_times(node):
    """動畫裡所有時間軸（骨頭、插槽、deform…）的關鍵格時間；Spine 會刪掉尾端重複的關鍵格，只看骨頭會量短。"""
    if isinstance(node, list):
        yield from (k.get("time", 0) for k in node if isinstance(k, dict))
    elif isinstance(node, dict):
        for v in node.values():
            yield from key_times(v)


def step_size(ctx):
    """確認尺寸（輸出前）：反向匯出 .spine 查 root 與動畫長度，Spine 實際算圖量第 0 格，對 PSD × 輸出縮放；產生版面對照。"""
    info = json.load(open(ctx.wpath("textures.json"), encoding="utf-8"))
    tol = ctx.cfg.get("verify", {}).get("tolerance", 2)
    vdir = ctx.wpath("verify")
    shutil.rmtree(vdir, ignore_errors=True)
    os.makedirs(os.path.join(vdir, "json"))
    os.makedirs(os.path.join(vdir, "render"))
    js = ctx.wpath("export_json.json")
    json.dump(tpl("spine", "export_json.json"), open(js, "w", encoding="utf-8"), indent=1)
    progress("size", 0, 3, "反向匯出")
    spine_cli(ctx, "-i", ctx.spine_file, "-o", os.path.join(vdir, "json"), "-e", js)
    rp = ctx.wpath("render_png.json")
    json.dump(tpl("spine", "render_png.json"), open(rp, "w", encoding="utf-8"), indent=1)
    progress("size", 1, 3, "Spine 算圖")
    spine_cli(ctx, "-i", ctx.spine_file, "-o", os.path.join(vdir, "render"), "-e", rp)
    progress("size", 2, 3, "量尺寸")
    _, keys = anim_keys(ctx)
    want_dur = keys[-1]["time"]
    rows, ok = [], True
    for s in ctx.symbols:
        i = info[s["code"]]
        sk = i["skeleton"]
        j = json.load(open(os.path.join(vdir, "json", sk + ".json"), encoding="utf-8"))
        root = j["bones"][0].get("scaleX", 1)
        an = j.get("animations", {}).get(ctx.anim["name"])
        dur = max(key_times(an), default=0) if an else None
        frames = sorted(glob.glob(os.path.join(vdir, "render", f"{sk}-{ctx.anim['name']}_*.png")))
        a = np.asarray(Image.open(frames[0]).convert("RGBA"))[..., 3]
        ys, xs = np.nonzero(a > 7)
        got = (int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1))
        want = (i["psdBox"][0] * ctx.scale, i["psdBox"][1] * ctx.scale)  # PSD 設計稿像素 × 輸出縮放
        checks = {
            "root": abs(root - ctx.root_scale) < 1e-6,
            "duration": dur is not None and abs(dur - want_dur) < 1e-3,
            "frame0": abs(got[0] - want[0]) <= tol and abs(got[1] - want[1]) <= tol,
        }
        ok &= all(checks.values())
        rows.append({"skeleton": sk, "root": root, "duration": dur, "frame0": got, "expected": [round(want[0], 1), round(want[1], 1)],
                     "frames": len(frames), "pass": checks})
        flag = "通過" if all(checks.values()) else "不符合 " + ",".join(k for k, v in checks.items() if not v)
        print(f"  {sk}: root {root}｜{ctx.anim['name']} {dur} 秒｜第 0 格 {got[0]}×{got[1]}｜預期 {want[0]:.1f}×{want[1]:.1f}｜{flag}")
    lay = ctx.cfg.get("verify", {}).get("layout")
    if lay:
        layout_compare(ctx, lay, info, vdir)
    progress("size", 3, 3)
    json.dump({"pass": ok, "rows": rows}, open(ctx.wpath("size.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if not ok:
        raise RuntimeError("尺寸不符，見 " + ctx.wpath("size.json"))
    print("  尺寸全部符合")


def step_verify(ctx):
    """驗證（輸出後）：交付檔齊全、圖集區域＝遊戲像素，合併尺寸檢查寫成完整報告。"""
    info = json.load(open(ctx.wpath("textures.json"), encoding="utf-8"))
    size = json.load(open(ctx.wpath("size.json"), encoding="utf-8"))
    tol = ctx.cfg.get("verify", {}).get("tolerance", 2)
    out = os.path.join(ctx.spine_dir, "Export")
    regions = atlas_regions(out)
    atlases = glob.glob(os.path.join(out, "*.atlas"))
    pages = [p for a in atlases for p in re.findall(r"^(\S+\.png)$", open(a, encoding="utf-8").read(), re.M)]
    want_atlas = 1 if ctx.cfg.get("export", {}).get("packTarget", "all") == "all" else len(ctx.symbols)
    files_ok = len(atlases) == want_atlas and all(os.path.exists(os.path.join(out, p)) for p in pages)
    print(f"  圖集 {len(atlases)} 組（應為 {want_atlas}）、頁圖 {len(pages)} 張：{'齊全' if files_ok else '缺檔'}")
    rows, ok = [], files_ok and size["pass"]
    for idx, (s, srow) in enumerate(zip(ctx.symbols, size["rows"])):
        progress("verify", idx, len(ctx.symbols), s["code"])
        i = info[s["code"]]
        reg = regions.get(i["image"])
        want = srow["expected"]
        checks = dict(srow["pass"])
        checks["skel"] = os.path.exists(os.path.join(out, i["skeleton"] + ".skel"))
        checks["atlas"] = reg is not None and abs(reg[0] - want[0]) <= tol and abs(reg[1] - want[1]) <= tol
        ok &= all(checks.values())
        rows.append({**srow, "atlas": reg, "pass": checks})
        flag = "通過" if all(checks.values()) else "不符合 " + ",".join(k for k, v in checks.items() if not v)
        print(f"  {i['skeleton']}: skel {'有' if checks['skel'] else '缺'}｜圖集區域 {reg}｜預期 {want[0]}×{want[1]}｜{flag}")
    progress("verify", len(ctx.symbols), len(ctx.symbols))
    json.dump({"pass": ok, "files": files_ok, "rows": rows}, open(ctx.wpath("report.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if not ok:
        raise RuntimeError("驗證未通過，見 " + ctx.wpath("report.json"))
    print("  驗證全部通過")


def layout_compare(ctx, lay, info, vdir):
    """設定稿縮到輸出解析度後，跟 Spine 第 0 格並排，輸出對照圖。"""
    from PIL import ImageDraw, ImageFont
    k = ctx.scale
    mock = Image.open(ctx.path(lay["reference"])).convert("RGB")
    mock = mock.resize((round(mock.width * k), round(mock.height * k)), Image.LANCZOS)
    font = ImageFont.truetype("C:/Windows/Fonts/msjh.ttc", 15)
    cells = lay["cells"]
    CW = max(round((c[2] - c[0]) * k) for c in cells.values()) + 8
    sheet = Image.new("RGB", (CW * 2 + 200, 30 + CW * len(cells)), (30, 10, 10))
    d = ImageDraw.Draw(sheet)
    d.text((8, 6), "設定稿（縮到輸出）", font=font, fill=(240, 220, 200))
    d.text((CW + 8, 6), "Spine 第 0 格", font=font, fill=(240, 220, 200))
    for r, (code, (x0, y0, x1, y1)) in enumerate(cells.items()):
        box = [round(v * k) for v in (x0, y0, x1, y1)]
        cell = mock.crop(box)
        y = 30 + r * CW
        sheet.paste(cell, (0, y))
        sk = info[code]["skeleton"]
        f0 = Image.open(sorted(glob.glob(os.path.join(vdir, "render", f"{sk}-{ctx.anim['name']}_*.png")))[0]).convert("RGBA")
        a = np.asarray(f0)[..., 3]
        ys, xs = np.nonzero(a > 7)
        sym = f0.crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
        bg = Image.new("RGBA", cell.size, (60, 16, 18, 255))
        bg.alpha_composite(sym, ((cell.width - sym.width) // 2, (cell.height - sym.height) // 2))
        sheet.paste(bg.convert("RGB"), (CW, y))
        d.multiline_text((CW * 2 + 10, y + 20), f"{code}\nSpine {sym.width}×{sym.height}", font=font, fill=(240, 220, 200), spacing=4)
    out = os.path.join(ctx.spine_dir, "Previews", "版面尺寸對照.png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    sheet.save(out)
    print(f"  版面對照圖 → {out}")


# ---------- preview ----------
def step_preview(ctx):
    info = json.load(open(ctx.wpath("textures.json"), encoding="utf-8"))
    vdir = ctx.wpath("verify", "render")
    pv = ctx.cfg.get("preview", {})
    cell, bg = pv.get("cell", 140), tuple(pv.get("background", [52, 18, 18]))
    seqs = [sorted(glob.glob(os.path.join(vdir, f"{info[s['code']]['skeleton']}-{ctx.anim['name']}_*.png"))) for s in ctx.symbols]
    if not all(seqs):
        raise RuntimeError("沒有算圖結果，先跑 size")
    fdir = ctx.wpath("preview_frames")
    shutil.rmtree(fdir, ignore_errors=True)
    os.makedirs(fdir)
    frames = []
    for f in range(len(seqs[0])):
        if f % 6 == 0:
            progress("preview", f, len(seqs[0]), f"第 {f} 格")
        canvas = Image.new("RGBA", (cell * len(seqs), cell), bg + (255,))
        for i, seq in enumerate(seqs):
            im = Image.open(seq[f]).convert("RGBA")
            canvas.alpha_composite(im, (i * cell + (cell - im.width) // 2, (cell - im.height) // 2))
        canvas = canvas.convert("RGB")
        canvas.save(os.path.join(fdir, f"{f:03d}.png"))
        frames.append(canvas)
    fps = ctx.anim.get("fps", 30)
    out = os.path.join(ctx.spine_dir, "Previews", f"{ctx.spine_name}_{ctx.anim['name']}.mp4")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if not shutil.which("ffmpeg"):
        print("  沒有安裝 ffmpeg：略過預覽影片（不影響 Spine 交付檔）")
        out = None
    code, msg = (0, "") if out is None else run(["ffmpeg", "-v", "error", "-y", "-stream_loop", str(pv.get("loops", 3) - 1), "-framerate", str(fps),
                     "-i", os.path.join(fdir, "%03d.png"), "-vf", "scale=iw*2:ih*2:flags=neighbor",
                     "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "16", out])
    if code:
        raise RuntimeError("ffmpeg 失敗：" + msg)
    if out:
        print(f"  預覽影片 → {out}")
    if pv.get("webp") and ctx.trial:
        print("  試跑資料夾：略過說明書動態圖（不寫正式位置）")
    elif pv.get("webp"):
        wp = ctx.path(pv["webp"])
        frames[0].save(wp, save_all=True, append_images=frames[1:], duration=1000 / fps, loop=0, quality=92, method=6)
        print(f"  動態圖 → {wp}")


# ---------- showcase ----------
def step_showcase(ctx):
    sc = ctx.cfg.get("showcase")
    if not sc:
        print("  設定檔沒有 showcase，略過")
        return
    if ctx.trial:
        print("  試跑資料夾：略過登記展示台（不改正式的 assets.json）")
        return
    path = sc["assets"]
    assets = json.load(open(path, encoding="utf-8"))
    try:
        base = os.path.relpath(os.path.join(ctx.spine_dir, "Export"), ctx.root).replace("\\", "/")
    except ValueError:
        raise RuntimeError(f"Spine 專案（{ctx.spine_dir}）不在專案 root（{ctx.root}）底下，展示台讀不到；試跑資料夾請略過 showcase")
    atlas = [os.path.basename(a) for a in glob.glob(os.path.join(ctx.spine_dir, "Export", "*.atlas"))]
    assets["spineSize"] = sc.get("spineSize", assets.get("spineSize"))
    for s in ctx.symbols:
        sk = ctx.skel(s)
        at = atlas[0] if len(atlas) == 1 else sk + ".atlas"
        assets.setdefault("symbols", {})[s.get("showcaseCode", s["code"])] = {
            "spine": {"skel": f"{base}/{sk}.skel", "atlas": f"{base}/{at}"}, "anims": {"win": ctx.anim["name"]}}
    json.dump(assets, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    progress("showcase", 1, 1)
    open(path, "a", encoding="utf-8").write("\n")
    print(f"  已登記 {len(ctx.symbols)} 個圖騰到 {path}")


def main():
    ap = argparse.ArgumentParser(description="簡易圖騰動畫產生器（設定檔驅動）")
    ap.add_argument("config")
    ap.add_argument("--steps", default=",".join(STEPS), help="逗號分隔：" + ",".join(STEPS))
    ap.add_argument("--spine-dir", help="覆寫輸出的 Spine 專案資料夾（試跑用）")
    ap.add_argument("--force", action="store_true", help="Spine 編輯器開著同名專案也照跑")
    a = ap.parse_args()
    ctx = Ctx(a.config, a.spine_dir, a.force)
    steps = [s.strip() for s in a.steps.split(",") if s.strip()]
    for s in steps:
        if s not in STEPS:
            sys.exit(f"沒有這個步驟：{s}")
    print(f"設定：{ctx.cfg_path}\nSpine 專案：{ctx.spine_file}\n工作區：{ctx.work}")
    for s in steps:
        print(f"[{s}]")
        try:
            globals()["step_" + s](ctx)
        except Exception as e:
            sys.exit(f"[{s}] 失敗：{e}")
    print("完成")


if __name__ == "__main__":
    main()
